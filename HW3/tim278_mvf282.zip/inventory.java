public class inventory{
	String name;
	String color;
	int q;
	public inventory(String name, String color, int quant) {
		this.name = name;
		this.color = color;
		q = quant;
	}
}